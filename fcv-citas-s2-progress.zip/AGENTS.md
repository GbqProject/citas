# AGENTS.md — Orquestación del workspace FCV Citas

## Contexto y alcance

Este workspace contiene exactamente dos repositorios independientes:

- `citas-api`: Java 21, Spring Boot 3.5.x, Maven, arquitectura hexagonal, MySQL 8.4 y Flyway.
- `citas-web`: frontend TypeScript que se importará desde Stitch/Google AI Studio; React o Angular se determinará por el proyecto real.

La raíz no es un tercer repositorio. La lógica de negocio pertenece a `citas-api`; la interfaz pertenece a `citas-web`; el frontend consume la API REST de Spring Boot de forma directa, sin Express ni BFF.

## Fuentes de verdad

Antes de cambios transversales, consultar en este orden:

1. `README.md`, `PRD.md` y `RESTRICCIONES_TECNICAS.md`.
2. `database/REQUISITOS_NORMALIZACION_3FN.md` y el diseño propio bajo `database/database_v1/`.
3. Las HU aprobadas en `citas-api/docs/wiki/scrum/`.
4. La LLM Wiki, comenzando por `citas-api/docs/wiki/llm-wiki/wiki/index.md`.
5. Los `AGENTS.md` específicos del repositorio, cuando existan.

No inventar requisitos fuera del PRD o de una HU aprobada. Los datos del laboratorio deben ser sintéticos; nunca usar datos privados o reales de pacientes/profesionales FCV.

## Flujo de trabajo

- Trabajar en `develop`; `main` es estable. No reescribir historial.
- Antes de modificar contratos REST, producir un plan que indique repositorios y archivos afectados.
- Usar la HU aprobada como unidad de alcance; mantener sus criterios de aceptación y DoD trazables.
- Mantener contraseñas, JWT, tokens, credenciales y demás secretos exclusivamente en variables de entorno. Nunca registrarlos ni versionarlos.
- Las migraciones del backend se realizan con Flyway; no modificar una base productiva/manualmente para sustituir una migración.
- Los workflows n8n se versionan como JSON en `citas-api/automations/n8n/`.

## Coordinación

- Tareas de backend: actuar dentro de `citas-api`.
- Tareas de frontend: actuar dentro de `citas-web` solo después de que exista el proyecto importado.
- Cambios de contrato: coordinar API y web, y verificar ambos lados.
- El AGENTS de `citas-api` se crea después de inicializar Spring Boot; el de `citas-web`, después de importar AI Studio. No asumir el framework del frontend antes de detectarlo.

## LLM Wiki

La memoria global vive únicamente en `citas-api/docs/wiki/llm-wiki/`:

- `raw/`: inventario de fuentes aprobadas e inmutables.
- `wiki/`: síntesis verificadas, decisiones, arquitectura, riesgos e índice.
- `schema/`: convenciones de mantenimiento.

Realizar INGEST desde fuentes aprobadas; mantener `wiki/index.md` y añadir eventos a `wiki/log.md`. Registrar solo conocimiento durable y clasificarlo como HECHO, DECISIÓN, PREFERENCIA o PREGUNTA ABIERTA. No convertir la wiki en una transcripción ni almacenar secretos o PII.
